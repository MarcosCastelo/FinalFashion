package models;

import java.util.ArrayList;

public class Conversa {
    private ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
    ArrayList<Mensagem> mensagens = new ArrayList<Mensagem>();

    public Conversa(ArrayList<Usuario> usuarios){
        this.usuarios = usuarios;
    }

    public boolean enviarMensagem(Usuario u, String conteudo){
        if(usuarios.contains(u) && conteudo.length() > 0) {
            Mensagem menssagem = new Mensagem(u.id, conteudo);
            mensagens.add(menssagem);
            return true;
        }
        return false;
    }

    public Mensagem buscarMensagem(int idMensagem){
        for (Mensagem m : mensagens) {
            if (m.getId() == idMensagem) {
                return m;
            }
        }
        return null;
    }

    public boolean deletarMensagem(int idMensagem){
        Mensagem m = buscarMensagem(idMensagem);
        if(m != null){
            mensagens.remove(m);
            return true;
        }
        return false;
    }

    public ArrayList<Mensagem> ArrayListarMensagens(){
        return mensagens;
    }

    public ArrayList<Usuario> ArrayListarUsuarios(){
        return usuarios;
    }

    @Override
    public String toString() {
        String string = "Users: < "+usuarios+" >\nMensagens:\n";
        for(Mensagem m : mensagens){
            string += m.toString() + "\n";
        }
        return string;
    }
}
