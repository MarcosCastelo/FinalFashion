package models;

public class Anuncio {
    int id;
    int userId;
    double preco;
    String titulo;
    String descricao;

    public Anuncio(int id, int userId, double preco, String titulo, String descricao) {
        this.id = id;
        this.userId = userId;
        this.preco = preco;
        this.titulo = titulo;
        this.descricao = descricao;
    }


    public double getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Anuncio(titulo:" + titulo + " id:"+ id +" userid:" + userId+ " " + preco + " " + descricao;
    }
}
