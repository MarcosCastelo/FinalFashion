package models;

public class Favorito {
    Anuncio anuncio;
    int userId;
    int id;

    Favorito(int id, int userId, Anuncio anuncio){
        this.anuncio = anuncio;
        this.id = id;
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Favorito(id:" + id + " " + anuncio.toString();
    }

    public int getId() {
        return id;
    }
}
