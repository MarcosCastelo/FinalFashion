package models;

import java.util.ArrayList;

public class Usuario {
    int id;
    String email;
    String senha;
    String phone;
    ArrayList<Anuncio> anuncios = new ArrayList<Anuncio>();
    ArrayList<Favorito> favoritos = new ArrayList<Favorito>();

    public Usuario(int id, String email, String senha, String phone){
        this.id = id;
        this.email = email;
        this.senha = senha;
        this.phone = phone;
    }

    public boolean createAnuncio(int id, double preco, String titulo, String descricao){
        Anuncio anuncio = new Anuncio(id, this.id, preco, titulo, descricao);
        if(!anuncios.contains(anuncio)){
            anuncios.add(anuncio);
            return true;
        }
        return false;
    }


    private Anuncio buscarAnuncio(int anuncioId) {
        for (Anuncio a : anuncios) {
            if (a.getId() == anuncioId) {
                return a;
            }
        }
        return null;
    }

    public ArrayList<Anuncio> listarAnuncios(){
        return anuncios;
    }

    public boolean removerAnuncio(int anuncioId){
        Anuncio anuncio = buscarAnuncio(anuncioId);
        if(anuncio != null){
            anuncios.remove(anuncio);
            return true;
        }
        return false;
    }

    public boolean favoritarAnuncio(Favorito favorito){
        if(!favoritos.contains(favorito)){
            favoritos.add(favorito);
            return true;
        }

        return false;
    }

    public Favorito buscarFavorito(int favoritoId){
        for (Favorito f : favoritos) {
            if (f.getId() == favoritoId) {
                return f;
            }
        }
        return null;
    }

    public boolean removeFavorito(int favoriteId){
        Favorito fav = buscarFavorito(favoriteId);
        if(fav != null){
            favoritos.remove(fav);
            return true;
        }
        return false;
    }

    public ArrayList<Favorito> listarFavoritos(){
        return favoritos;
    }

}
