package models;

import java.util.Date;

public class Mensagem {
    int id;
    String conteudo;
    Date date = new Date();
    int emissor_id;

    public Mensagem( int emissor_id ,String conteudo) {
        this.conteudo = conteudo;
        this.emissor_id = emissor_id;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return emissor_id + ": ( " + conteudo + " ) - " + date;
    }
}
