import models.Anuncio;
import models.Conversa;
import models.Usuario;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args){

        ArrayList<Anuncio> anuncios = new ArrayList<Anuncio>();
        ArrayList<Usuario> users = new ArrayList<Usuario>();

        Usuario u1 = new Usuario(1,"m@m", "123", "123");
        Usuario u2 = new Usuario(2,"a@m", "321", "321");
        Usuario u3 = new Usuario(3,"b@m", "132", "132");

        users.add(u1);
        users.add(u2);
        users.add(u3);

        u1.createAnuncio(1, 20.0, "Camisa", "100% algodão");
        u1.createAnuncio(2, 35.0, "Calça", "Jeans");
        u1.createAnuncio(3, 15.0, "Boné", "Aba reta");

        System.out.println(u1.listarAnuncios());

        u2.createAnuncio(4, 20.0, "Cama", "Confortavel");
        u2.createAnuncio(5, 35.0, "Travesseiro", "Penas de ganso");
        u2.createAnuncio(6, 15.0, "Colcha de cama", "Impermeavel");

        System.out.println(u2.listarAnuncios());

        u3.createAnuncio(7, 20.0, "Toalha", "100% algodão");
        u3.createAnuncio(8, 35.0, "Ropão", "Confortavel");

        System.out.println(u3.listarAnuncios());

        anuncios.addAll(u1.listarAnuncios());
        anuncios.addAll(u2.listarAnuncios());
        anuncios.addAll(u3.listarAnuncios());

        Conversa conversa = new Conversa(users);

        conversa.enviarMensagem(u1, "Olá");
        conversa.enviarMensagem(u1, "Tudo bem?");
        conversa.enviarMensagem(u2, "Opa");
        conversa.enviarMensagem(u2, "Tudo bem");

        System.out.println(conversa);
        System.out.println(conversa.ArrayListarMensagens());


    }
}
